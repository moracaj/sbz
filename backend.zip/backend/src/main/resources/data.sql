MERGE INTO places (name, country, city, description)
KEY(name)
VALUES ('Novi Sad','Serbia','Novi Sad','Grad stanovanja');
