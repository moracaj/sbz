package com.example.sbz.web;

import com.example.sbz.model.Suspension;
import com.example.sbz.model.SuspensionType;
import com.example.sbz.repo.SuspensionRepo;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/suspensions")
@RequiredArgsConstructor
public class SuspensionPublicController {

  private final SuspensionRepo suspensionRepo;
   public SuspensionPublicController(SuspensionRepo suspensionRepo) {
	   this.suspensionRepo=suspensionRepo;
   }

  @GetMapping("/active")
  //@Transactional(readOnly = true)
  public List<Suspension> active(@RequestParam(required = false) SuspensionType type) {
    var now = Instant.now();
    return (type == null) ? suspensionRepo.findActive(now)
                          : suspensionRepo.findActiveByType(type, now);
  }
}
