package com.example.sbz.model;

public enum SuspensionType { POST_BAN, LOGIN_BAN }
