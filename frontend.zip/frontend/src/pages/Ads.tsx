export default function Ads(){
  return <div><h2>Ads</h2><p>Recommended places (backward-chaining rules) – optional if working solo.</p></div>
}