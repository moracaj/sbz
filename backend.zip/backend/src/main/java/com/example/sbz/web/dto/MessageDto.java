package com.example.sbz.web.dto;

public record MessageDto(String message) {}
