/*package com.example.sbz.web;

import com.example.sbz.model.Suspension;
import com.example.sbz.model.SuspensionType;
import com.example.sbz.repo.SuspensionRepo;
import com.example.sbz.service.BadUserDetectionService;
import com.example.sbz.web.dto.MessageDto;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
//@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminDetectionController {
 
	 private final SuspensionRepo suspensionRepo; // dodaj repo
	private final BadUserDetectionService detectionService;
  //public AdminDetectionController(BadUserDetectionService d) { this.detectionService = d; }
  
	 public AdminDetectionController(SuspensionRepo suspensionRepo,
             BadUserDetectionService detectionService) {
			this.suspensionRepo = suspensionRepo;
			this.detectionService = detectionService;
}
	
	 @PostMapping("/detect-bad-users")
	 @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	  public List<Suspension> detect() {
	    detectionService.detectBadUsers();                  // kreira/produži suspenzije
	    return suspensionRepo.findActive(Instant.now());    // vrati sve aktivne
	  }
  
	 @GetMapping("/suspensions/active")
	 @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	  public List<Suspension> active(@RequestParam(required = false) SuspensionType type) {
	    var now = Instant.now();
	    return (type == null) ? suspensionRepo.findActive(now)
	                          : suspensionRepo.findActiveByType(type, now);
	  }

	 @PostMapping("/suspensions/user/{userId}/lift")
	 @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	  public MessageDto lift(@PathVariable Long userId) {
	    var now = Instant.now();
	    suspensionRepo.deactivateAllForUser(userId, now);
	    return new MessageDto("All active suspensions lifted.");
	  }
}*/

package com.example.sbz.web;

import com.example.sbz.model.Suspension;
import com.example.sbz.model.SuspensionType;
import com.example.sbz.model.User;
import com.example.sbz.repo.SuspensionRepo;
import com.example.sbz.repo.UserRepo;
import com.example.sbz.service.BadUserDetectionService;
import com.example.sbz.web.dto.MessageDto;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

@CrossOrigin(origins = {"http://localhost:5173","http://127.0.0.1:5173"})
@RestController
@RequestMapping("/api/admin") // ostavljam isto da ti ne rušim FE; vidi napomenu dole
public class AdminDetectionController {

  private final SuspensionRepo suspensionRepo;
  private final BadUserDetectionService detectionService;
  private final UserRepo userRepo;

  public AdminDetectionController(SuspensionRepo suspensionRepo,
                                  BadUserDetectionService detectionService,
                                  UserRepo userRepo) {
    this.suspensionRepo = suspensionRepo;
    this.detectionService = detectionService;
    this.userRepo = userRepo;
  }

  // --- helpers kao u PlaceController-u ---
  private User me(Authentication auth){
    if (auth == null || auth.getPrincipal() == null)
      throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "No auth");
    String email = Objects.toString(auth.getPrincipal(), null);
    return userRepo.findByEmail(email)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not found"));
  }

  private void requireAdmin(User u){
    if (u == null || !u.isAdmin())
      throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Admin only");
  }

  // --- ADMIN ONLY: pokretanje detekcije ---
  @PostMapping("/detect-bad-users")
  @Transactional
  public List<Suspension> detect(Authentication auth) {
    User admin = me(auth);
    requireAdmin(admin);

    // pokreni pravila i upiši/prodûži suspenzije
    detectionService.detectBadUsers();
    // vrati trenutno aktivne
    return suspensionRepo.findActive(Instant.now());
  }

  // --- PREGLED AKTIVNIH (trenutno pod /api/admin; vidi napomenu) ---
  @GetMapping("/suspensions/active")
  @Transactional(readOnly = true)
  public List<Suspension> active(@RequestParam(required = false) SuspensionType type) {
    var now = Instant.now();
    return (type == null) ? suspensionRepo.findActive(now)
                          : suspensionRepo.findActiveByType(type, now);
  }

  // --- ADMIN ONLY: skidanje suspenzija korisniku ---
  @PostMapping("/suspensions/user/{userId}/lift")
  @Transactional
  public MessageDto lift(@PathVariable Long userId, Authentication auth) {
    User admin = me(auth);
    requireAdmin(admin);

    var now = Instant.now();
    suspensionRepo.deactivateAllForUser(userId, now);
    return new MessageDto("All active suspensions lifted.");
  }
}

