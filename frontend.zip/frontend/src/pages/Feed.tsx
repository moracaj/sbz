export default function Feed(){
  return <div><h2>Feed</h2><p>Friends + Recommended posts (to be implemented)</p></div>
}